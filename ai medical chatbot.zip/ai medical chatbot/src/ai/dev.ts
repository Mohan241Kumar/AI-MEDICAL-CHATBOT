import '@/ai/flows/analyze-image.ts';
import '@/ai/flows/voice-diagnosis.ts';
import '@/ai/flows/symptom-checker-flow.ts'; // Added symptom checker
import '@/ai/flows/mental-health-flow.ts'; // Added mental health
import '@/ai/flows/dietary-analysis-flow.ts'; // Added dietary analysis

    